import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useStore } from '@/context/StoreContext';
import { useRoute } from '@/context/RouteContext';
import { t } from '@/lib/i18n';
import type { Category } from '@/types';
import { Wheat, Candy, CupSoda, GlassWater, Package, ArrowLeft, ArrowRight } from 'lucide-react';

const iconMap: Record<string, typeof Wheat> = {
  Wheat: Wheat,
  Candy: Candy,
  CupSoda: CupSoda,
  GlassWater: GlassWater,
};

export default function Categories() {
  const { lang, currency } = useStore();
  const { navigate } = useRoute();
  const [categories, setCategories] = useState<Category[]>([]);
  const [counts, setCounts] = useState<Record<string, number>>({});
  const [selected, setSelected] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const { data: cats } = await supabase
        .from('categories')
        .select('*')
        .order('sort_order');
      if (cats) {
        setCategories(cats);
        const countMap: Record<string, number> = {};
        for (const c of cats) {
          const { count } = await supabase
            .from('products')
            .select('*', { count: 'exact', head: true })
            .eq('category_id', c.id)
            .eq('is_active', true);
          countMap[c.id] = count || 0;
        }
        setCounts(countMap);
      }
      setLoading(false);
    })();
  }, []);

  const Arrow = lang === 'ar' ? ArrowLeft : ArrowRight;

  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-32 rounded-2xl shimmer" />
        ))}
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-6 text-center">
        {t(lang, 'categories')}
      </h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
        {categories.map((cat) => {
          const Icon = iconMap[cat.icon || ''] || Package;
          return (
            <button
              key={cat.id}
              onClick={() => {
                setSelected(cat.id);
                navigate('store', { category: cat.id });
              }}
              className={`category-card relative overflow-hidden rounded-2xl p-6 text-center shadow-lg ${
                selected === cat.id
                  ? 'bg-gradient-to-br from-emerald-600 to-teal-500 text-white'
                  : 'bg-white text-gray-800 hover:bg-emerald-50'
              }`}
            >
              <div className={`absolute inset-0 opacity-10`}>
                <Icon className="w-full h-full" />
              </div>
              <div className="relative">
                <div
                  className={`w-14 h-14 mx-auto mb-3 rounded-2xl flex items-center justify-center ${
                    selected === cat.id ? 'bg-white/20' : 'bg-emerald-100'
                  }`}
                >
                  <Icon className={`w-7 h-7 ${selected === cat.id ? 'text-white' : 'text-emerald-600'}`} />
                </div>
                <h3 className="font-bold text-base md:text-lg mb-1">
                  {lang === 'ar' ? cat.name_ar : cat.name_en}
                </h3>
                <p className={`text-sm ${selected === cat.id ? 'text-white/80' : 'text-gray-500'}`}>
                  {counts[cat.id] || 0} {t(lang, 'products')}
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
