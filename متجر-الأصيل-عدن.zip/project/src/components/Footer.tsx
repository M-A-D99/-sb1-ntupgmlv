import { Store, MapPin, Phone, ShoppingBag } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { t } from '@/lib/i18n';

export default function Footer() {
  const { lang } = useStore();

  return (
    <footer className="bg-gradient-to-b from-gray-900 to-gray-800 text-white mt-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Store info */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-400 flex items-center justify-center">
                <Store className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-lg font-bold">{t(lang, 'storeName')}</div>
                <div className="text-sm text-emerald-400">{t(lang, 'storeCity')}</div>
              </div>
            </div>
            <p className="text-gray-400 text-sm">{t(lang, 'tagline')}</p>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-bold text-lg mb-4">{t(lang, 'contactUs')}</h3>
            <div className="space-y-3 text-sm text-gray-400">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-emerald-400" />
                <span>{t(lang, 'addressValue')}</span>
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 text-emerald-400" />
                <span>+967 7XX XXX XXX</span>
              </div>
              <div className="flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-emerald-400" />
                <span>{lang === 'ar' ? 'بيع بالجملة' : 'Wholesale'}</span>
              </div>
            </div>
          </div>

          {/* About */}
          <div>
            <h3 className="font-bold text-lg mb-4">{lang === 'ar' ? 'عن المتجر' : 'About Store'}</h3>
            <p className="text-gray-400 text-sm leading-relaxed">
              {lang === 'ar'
                ? 'متجر الأصيل - عدن، متجر إلكتروني متخصص في بيع المواد الغذائية والحلويات والمشروبات بالجملة. نوفر أسعار تنافسية وتوصيل سريع لجميع مناطق عدن.'
                : 'Al-Aseel Store - Aden, an online wholesale store specializing in food products, sweets, and beverages. We offer competitive prices and fast delivery across Aden.'}
            </p>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-8 pt-6 text-center text-sm text-gray-500">
          <p>© 2026 {t(lang, 'footerText')}</p>
        </div>
      </div>
    </footer>
  );
}
