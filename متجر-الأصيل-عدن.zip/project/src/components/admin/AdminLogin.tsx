import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useStore } from '@/context/StoreContext';
import { useRoute } from '@/context/RouteContext';
import { t } from '@/lib/i18n';
import { Lock, Mail, Loader2, Store, ArrowLeft, ArrowRight } from 'lucide-react';

export default function AdminLogin() {
  const { lang } = useStore();
  const { navigate } = useRoute();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const { data, error: authError } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (authError || !data.user) {
      setError(t(lang, 'loginError'));
      setLoading(false);
      return;
    }

    // Will trigger auth state change which redirects
    setLoading(false);
  };

  const Arrow = lang === 'ar' ? ArrowLeft : ArrowRight;

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-8">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
          {/* Header */}
          <div className="hero-gradient p-8 text-center text-white">
            <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center float-anim">
              <Lock className="w-8 h-8" />
            </div>
            <h2 className="text-2xl font-bold">{t(lang, 'adminLogin')}</h2>
            <p className="text-white/80 text-sm mt-1">{t(lang, 'welcomeAdmin')}</p>
          </div>

          {/* Form */}
          <form onSubmit={handleLogin} className="p-8 space-y-4">
            {error && (
              <div className="bg-red-50 text-red-600 text-sm rounded-xl p-3 font-semibold">
                {error}
              </div>
            )}

            <div>
              <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'email')}</label>
              <div className="relative">
                <Mail className="absolute top-1/2 -translate-y-1/2 left-3 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none"
                  placeholder="admin@example.com"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'password')}</label>
              <div className="relative">
                <Lock className="absolute top-1/2 -translate-y-1/2 left-3 w-5 h-5 text-gray-400" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="btn-3d w-full py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 disabled:opacity-50 flex items-center justify-center gap-2"
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                t(lang, 'login')
              )}
            </button>

            <button
              type="button"
              onClick={() => navigate('store')}
              className="w-full py-3 text-gray-500 font-semibold hover:text-emerald-600 flex items-center justify-center gap-1 text-sm"
            >
              {t(lang, 'backToStore')}
              <Arrow className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
