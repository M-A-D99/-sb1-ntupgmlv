import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useStore } from '@/context/StoreContext';
import { useRoute } from '@/context/RouteContext';
import { t } from '@/lib/i18n';
import { Package, ShoppingCart, Clock, DollarSign, TrendingUp, Plus, Edit2, Trash2, X, Save, ArrowLeft, ArrowRight } from 'lucide-react';
import type { Product, Category, Order, OrderStatus } from '@/types';

type Tab = 'dashboard' | 'products' | 'orders';

export default function AdminDashboard() {
  const { lang, currency } = useStore();
  const { navigate } = useRoute();
  const [tab, setTab] = useState<Tab>('dashboard');
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [showProductForm, setShowProductForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAll();
  }, []);

  const fetchAll = async () => {
    const [{ data: prods }, { data: ords }, { data: cats }] = await Promise.all([
      supabase.from('products').select('*, category:categories(*)').order('sort_order'),
      supabase.from('orders').select('*, order_items(*)').order('created_at', { ascending: false }),
      supabase.from('categories').select('*').order('sort_order'),
    ]);
    if (prods) setProducts(prods as unknown as Product[]);
    if (ords) setOrders(ords as Order[]);
    if (cats) setCategories(cats);
    setLoading(false);
  };

  const stats = {
    totalOrders: orders.length,
    totalProducts: products.length,
    pendingOrders: orders.filter((o) => o.status === 'pending').length,
    totalRevenueYer: orders
      .filter((o) => o.status === 'delivered')
      .reduce((sum, o) => sum + o.total_yer, 0),
    totalRevenueSar: orders
      .filter((o) => o.status === 'delivered')
      .reduce((sum, o) => sum + o.total_sar, 0),
  };

  const statusColors: Record<OrderStatus, string> = {
    pending: 'bg-amber-100 text-amber-700',
    confirmed: 'bg-blue-100 text-blue-700',
    shipped: 'bg-purple-100 text-purple-700',
    delivered: 'bg-emerald-100 text-emerald-700',
    cancelled: 'bg-red-100 text-red-700',
  };

  const statusLabel = (s: OrderStatus) => {
    const map: Record<OrderStatus, string> = {
      pending: t(lang, 'pending'),
      confirmed: t(lang, 'confirmed'),
      shipped: t(lang, 'shipped'),
      delivered: t(lang, 'delivered'),
      cancelled: t(lang, 'cancelled'),
    };
    return map[s];
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('store');
  };

  const handleDeleteProduct = async (id: string) => {
    if (!confirm(t(lang, 'confirmDelete'))) return;
    await supabase.from('products').delete().eq('id', id);
    setProducts(products.filter((p) => p.id !== id));
  };

  const handleUpdateOrderStatus = async (id: string, status: OrderStatus) => {
    await supabase.from('orders').update({ status }).eq('id', id);
    setOrders(orders.map((o) => (o.id === id ? { ...o, status } : o)));
  };

  const Arrow = lang === 'ar' ? ArrowLeft : ArrowRight;

  const statCards = [
    { icon: ShoppingCart, label: t(lang, 'totalOrders'), value: stats.totalOrders, color: 'from-blue-500 to-blue-600' },
    { icon: Package, label: t(lang, 'totalProducts'), value: stats.totalProducts, color: 'from-emerald-500 to-emerald-600' },
    { icon: Clock, label: t(lang, 'pendingOrders'), value: stats.pendingOrders, color: 'from-amber-500 to-amber-600' },
    {
      icon: DollarSign,
      label: t(lang, 'totalRevenue'),
      value: currency === 'YER'
        ? new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(stats.totalRevenueYer) + ' ر.ي'
        : new Intl.NumberFormat('en-US', { maximumFractionDigits: 0 }).format(stats.totalRevenueSar) + ' ر.س',
      color: 'from-teal-500 to-teal-600',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Admin header bar */}
      <div className="bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-400 flex items-center justify-center">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-lg font-bold">{t(lang, 'dashboard')}</h1>
              <p className="text-xs text-gray-400">{t(lang, 'storeName')} - {t(lang, 'storeCity')}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate('store')}
              className="text-sm font-semibold text-gray-300 hover:text-white px-3 py-2 rounded-lg hover:bg-white/10 flex items-center gap-1"
            >
              {t(lang, 'backToStore')}
              <Arrow className="w-4 h-4" />
            </button>
            <button
              onClick={handleLogout}
              className="text-sm font-semibold text-red-300 hover:text-red-200 px-3 py-2 rounded-lg hover:bg-red-500/20"
            >
              {t(lang, 'logout')}
            </button>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex gap-2 mb-6 border-b">
          {([
            { key: 'dashboard', label: t(lang, 'dashboard') },
            { key: 'products', label: t(lang, 'manageProducts') },
            { key: 'orders', label: t(lang, 'manageOrders') },
          ] as { key: Tab; label: string }[]).map((tabItem) => (
            <button
              key={tabItem.key}
              onClick={() => setTab(tabItem.key)}
              className={`px-4 py-3 font-semibold text-sm transition-colors border-b-2 -mb-px ${
                tab === tabItem.key
                  ? 'text-emerald-600 border-emerald-600'
                  : 'text-gray-500 border-transparent hover:text-gray-700'
              }`}
            >
              {tabItem.label}
              {tabItem.key === 'orders' && stats.pendingOrders > 0 && (
                <span className="mr-2 px-2 py-0.5 bg-amber-500 text-white text-xs rounded-full">
                  {stats.pendingOrders}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Dashboard tab */}
        {tab === 'dashboard' && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
              {statCards.map((stat, i) => (
                <div
                  key={i}
                  className={`bg-gradient-to-br ${stat.color} rounded-2xl p-6 text-white shadow-lg card-3d`}
                >
                  <stat.icon className="w-8 h-8 mb-3 opacity-80" />
                  <div className="text-2xl md:text-3xl font-extrabold">{stat.value}</div>
                  <div className="text-sm text-white/80 mt-1">{stat.label}</div>
                </div>
              ))}
            </div>

            {/* Recent orders */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-lg text-gray-800 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-emerald-600" />
                  {t(lang, 'manageOrders')}
                </h3>
                <button
                  onClick={() => setTab('orders')}
                  className="text-sm text-emerald-600 font-semibold hover:underline"
                >
                  {lang === 'ar' ? 'عرض الكل' : 'View all'}
                </button>
              </div>
              {orders.length === 0 ? (
                <p className="text-gray-400 text-center py-8">{t(lang, 'noOrders')}</p>
              ) : (
                <div className="space-y-2">
                  {orders.slice(0, 5).map((order) => (
                    <div
                      key={order.id}
                      className="flex items-center justify-between p-3 rounded-xl bg-gray-50 hover:bg-gray-100 transition-colors"
                    >
                      <div>
                        <span className="font-semibold text-gray-700">#{order.id.slice(0, 8).toUpperCase()}</span>
                        <span className="text-sm text-gray-500 mx-2">{order.customer_name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-1 rounded-full text-xs font-bold ${statusColors[order.status]}`}>
                          {statusLabel(order.status)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* Products tab */}
        {tab === 'products' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-lg text-gray-800">{t(lang, 'manageProducts')}</h3>
              <button
                onClick={() => {
                  setEditingProduct(null);
                  setShowProductForm(true);
                }}
                className="btn-3d px-4 py-2 bg-emerald-600 text-white rounded-xl font-bold flex items-center gap-2 hover:bg-emerald-700"
              >
                <Plus className="w-4 h-4" />
                {t(lang, 'addProduct')}
              </button>
            </div>

            {loading ? (
              <div className="space-y-2">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="h-20 rounded-2xl shimmer" />
                ))}
              </div>
            ) : products.length === 0 ? (
              <p className="text-gray-400 text-center py-8">{t(lang, 'noProducts')}</p>
            ) : (
              <div className="space-y-2">
                {products.map((product) => (
                  <div
                    key={product.id}
                    className="bg-white rounded-2xl p-4 shadow-sm flex items-center gap-4"
                  >
                    <div className="w-16 h-16 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
                      {product.image_url ? (
                        <img src={product.image_url} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="w-6 h-6 text-gray-300" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="font-bold text-gray-800 truncate">
                        {lang === 'ar' ? product.name_ar : product.name_en}
                      </h4>
                      <div className="flex items-center gap-3 text-sm text-gray-500">
                        <span>{product.price_yer} ر.ي / {product.price_sar} ر.س</span>
                        <span>•</span>
                        <span>{t(lang, 'inStock')}: {product.stock}</span>
                        <span>•</span>
                        <span className={product.is_active ? 'text-emerald-600' : 'text-gray-400'}>
                          {product.is_active ? t(lang, 'active') : t(lang, 'inactive')}
                        </span>
                      </div>
                    </div>
                    <div className="flex gap-2 flex-shrink-0">
                      <button
                        onClick={() => {
                          setEditingProduct(product);
                          setShowProductForm(true);
                        }}
                        className="w-9 h-9 rounded-lg bg-blue-50 hover:bg-blue-100 flex items-center justify-center text-blue-600"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteProduct(product.id)}
                        className="w-9 h-9 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center text-red-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Product form modal */}
            {showProductForm && (
              <ProductForm
                product={editingProduct}
                categories={categories}
                lang={lang}
                onSave={async () => {
                  setShowProductForm(false);
                  await fetchAll();
                }}
                onCancel={() => setShowProductForm(false)}
              />
            )}
          </div>
        )}

        {/* Orders tab */}
        {tab === 'orders' && (
          <div>
            <h3 className="font-bold text-lg text-gray-800 mb-4">{t(lang, 'manageOrders')}</h3>
            {orders.length === 0 ? (
              <p className="text-gray-400 text-center py-8">{t(lang, 'noOrders')}</p>
            ) : (
              <div className="space-y-3">
                {orders.map((order) => {
                  const total = currency === 'YER' ? order.total_yer : order.total_sar;
                  const totalF = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(total);
                  const totalL = currency === 'YER' ? `${totalF} ر.ي` : `${totalF} ر.س`;
                  const date = new Date(order.created_at).toLocaleDateString(lang === 'ar' ? 'ar' : 'en');

                  return (
                    <div key={order.id} className="bg-white rounded-2xl p-4 shadow-sm">
                      <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                        <div>
                          <div className="font-bold text-gray-800">
                            #{order.id.slice(0, 8).toUpperCase()}
                          </div>
                          <div className="text-sm text-gray-500">
                            {t(lang, 'customer')}: {order.customer_name} | {t(lang, 'phoneLabel')}: {order.customer_phone}
                          </div>
                          <div className="text-sm text-gray-400">
                            {t(lang, 'orderDate')}: {date}
                          </div>
                          {order.customer_address && (
                            <div className="text-sm text-gray-400">
                              {t(lang, 'address')}: {order.customer_address}
                            </div>
                          )}
                          {order.customer_notes && (
                            <div className="text-sm text-gray-400">
                              {t(lang, 'customerNotes')}: {order.customer_notes}
                            </div>
                          )}
                        </div>
                        <div className="text-left">
                          <div className="font-extrabold text-emerald-600 text-lg">{totalL}</div>
                          <span className={`inline-block mt-1 px-3 py-1 rounded-full text-xs font-bold ${statusColors[order.status]}`}>
                            {statusLabel(order.status)}
                          </span>
                        </div>
                      </div>

                      {/* Items */}
                      {order.order_items && order.order_items.length > 0 && (
                        <div className="bg-gray-50 rounded-xl p-3 mb-3 space-y-1">
                          {order.order_items.map((item) => (
                            <div key={item.id} className="flex justify-between text-sm">
                              <span className="text-gray-600">
                                {lang === 'ar' ? item.product_name_ar : item.product_name_en} × {item.quantity}
                              </span>
                              <span className="font-semibold text-gray-700">
                                {new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(
                                  currency === 'YER' ? item.subtotal_yer : item.subtotal_sar
                                )} {currency === 'YER' ? 'ر.ي' : 'ر.س'}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Status update */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-sm text-gray-500 font-semibold">{t(lang, 'updateStatus')}:</span>
                      </div>
                      <div className="flex gap-2 flex-wrap mt-2">
                        {(['pending', 'confirmed', 'shipped', 'delivered', 'cancelled'] as OrderStatus[]).map((s) => (
                          <button
                            key={s}
                            onClick={() => handleUpdateOrderStatus(order.id, s)}
                            className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${
                              order.status === s
                                ? statusColors[s] + ' ring-2 ring-offset-1'
                                : 'bg-gray-100 text-gray-500 hover:bg-gray-200'
                            }`}
                          >
                            {statusLabel(s)}
                          </button>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Product form component
function ProductForm({
  product,
  categories,
  lang,
  onSave,
  onCancel,
}: {
  product: Product | null;
  categories: Category[];
  lang: 'ar' | 'en';
  onSave: () => void;
  onCancel: () => void;
}) {
  const [form, setForm] = useState({
    name_ar: product?.name_ar || '',
    name_en: product?.name_en || '',
    description_ar: product?.description_ar || '',
    description_en: product?.description_en || '',
    price_yer: product?.price_yer || 0,
    price_sar: product?.price_sar || 0,
    stock: product?.stock || 0,
    unit: product?.unit || 'كرتون / Carton',
    image_url: product?.image_url || '',
    category_id: product?.category_id || categories[0]?.id || '',
    is_active: product?.is_active ?? true,
    min_wholesale_qty: product?.min_wholesale_qty || 1,
    sort_order: product?.sort_order || 0,
  });
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    if (product) {
      await supabase.from('products').update(form).eq('id', product.id);
    } else {
      await supabase.from('products').insert(form);
    }
    setSaving(false);
    onSave();
  };

  const inputClass =
    'w-full px-3 py-2 rounded-lg border-2 border-gray-200 focus:border-emerald-500 focus:outline-none text-sm';

  return (
    <div className="fixed inset-0 z-[60] bg-black/50 flex items-center justify-center p-4 overflow-y-auto" onClick={onCancel}>
      <div
        className="bg-white rounded-2xl p-6 max-w-2xl w-full shadow-2xl my-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-gray-800">
            {product ? t(lang, 'editProduct') : t(lang, 'addProduct')}
          </h3>
          <button onClick={onCancel} className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'productNameAr')}</label>
            <input
              type="text"
              value={form.name_ar}
              onChange={(e) => setForm({ ...form, name_ar: e.target.value })}
              className={inputClass}
              dir="rtl"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'productNameEn')}</label>
            <input
              type="text"
              value={form.name_en}
              onChange={(e) => setForm({ ...form, name_en: e.target.value })}
              className={inputClass}
              dir="ltr"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'productDescAr')}</label>
            <textarea
              value={form.description_ar}
              onChange={(e) => setForm({ ...form, description_ar: e.target.value })}
              className={inputClass}
              rows={2}
              dir="rtl"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'productDescEn')}</label>
            <textarea
              value={form.description_en}
              onChange={(e) => setForm({ ...form, description_en: e.target.value })}
              className={inputClass}
              rows={2}
              dir="ltr"
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'priceYer')}</label>
            <input
              type="number"
              value={form.price_yer}
              onChange={(e) => setForm({ ...form, price_yer: parseFloat(e.target.value) || 0 })}
              className={inputClass}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'priceSar')}</label>
            <input
              type="number"
              value={form.price_sar}
              onChange={(e) => setForm({ ...form, price_sar: parseFloat(e.target.value) || 0 })}
              className={inputClass}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'stockQty')}</label>
            <input
              type="number"
              value={form.stock}
              onChange={(e) => setForm({ ...form, stock: parseInt(e.target.value) || 0 })}
              className={inputClass}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'unit')}</label>
            <input
              type="text"
              value={form.unit}
              onChange={(e) => setForm({ ...form, unit: e.target.value })}
              className={inputClass}
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'category')}</label>
            <select
              value={form.category_id}
              onChange={(e) => setForm({ ...form, category_id: e.target.value })}
              className={inputClass}
            >
              {categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {lang === 'ar' ? c.name_ar : c.name_en}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'minQty')}</label>
            <input
              type="number"
              value={form.min_wholesale_qty}
              onChange={(e) => setForm({ ...form, min_wholesale_qty: parseInt(e.target.value) || 1 })}
              className={inputClass}
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-semibold text-gray-600 mb-1">{t(lang, 'imageUrl')}</label>
            <input
              type="text"
              value={form.image_url}
              onChange={(e) => setForm({ ...form, image_url: e.target.value })}
              className={inputClass}
              placeholder="https://..."
            />
          </div>
          <div className="md:col-span-2 flex items-center gap-2">
            <input
              type="checkbox"
              id="is_active"
              checked={form.is_active}
              onChange={(e) => setForm({ ...form, is_active: e.target.checked })}
              className="w-5 h-5"
            />
            <label htmlFor="is_active" className="text-sm font-semibold text-gray-600">
              {form.is_active ? t(lang, 'active') : t(lang, 'inactive')}
            </label>
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={handleSave}
            disabled={saving}
            className="btn-3d flex-1 py-3 bg-emerald-600 text-white rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-emerald-700 disabled:opacity-50"
          >
            <Save className="w-4 h-4" />
            {t(lang, 'save')}
          </button>
          <button
            onClick={onCancel}
            className="flex-1 py-3 bg-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-300"
          >
            {t(lang, 'cancel')}
          </button>
        </div>
      </div>
    </div>
  );
}
