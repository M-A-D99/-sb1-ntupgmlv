import { useState } from 'react';
import { Plus, Minus, ShoppingCart, Package } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { t } from '@/lib/i18n';
import type { Product } from '@/types';

interface Props {
  product: Product;
}

export default function ProductCard({ product }: Props) {
  const { lang, currency, addToCart } = useStore();
  const [qty, setQty] = useState(product.min_wholesale_qty);
  const [added, setAdded] = useState(false);

  const price = currency === 'YER' ? product.price_yer : product.price_sar;
  const formatted = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(price);
  const priceLabel = currency === 'YER' ? `${formatted} ر.ي` : `${formatted} ر.س`;

  const inStock = product.stock > 0;
  const name = lang === 'ar' ? product.name_ar : product.name_en;
  const desc = lang === 'ar' ? product.description_ar : product.description_en;

  const handleAdd = () => {
    addToCart(product, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 1500);
  };

  return (
    <div className="card-3d bg-white rounded-2xl overflow-hidden shadow-md border border-gray-100 flex flex-col">
      {/* Image */}
      <div className="relative h-48 overflow-hidden bg-gray-100">
        {product.image_url ? (
          <img
            src={product.image_url}
            alt={name}
            className="product-img w-full h-full object-cover"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <Package className="w-16 h-16 text-gray-300" />
          </div>
        )}
        {/* Stock badge */}
        <div className="absolute top-2 right-2">
          {inStock ? (
            <span className="px-2 py-1 bg-emerald-500 text-white text-xs font-bold rounded-full shadow">
              {t(lang, 'inStock')}
            </span>
          ) : (
            <span className="px-2 py-1 bg-red-500 text-white text-xs font-bold rounded-full shadow">
              {t(lang, 'outOfStock')}
            </span>
          )}
        </div>
        {/* Min qty badge */}
        <div className="absolute top-2 left-2">
          <span className="px-2 py-1 bg-amber-500 text-white text-xs font-bold rounded-full shadow">
            {t(lang, 'minQty')}: {product.min_wholesale_qty}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col flex-1">
        <h3 className="font-bold text-gray-800 text-base mb-1 line-clamp-2">{name}</h3>
        {desc && <p className="text-sm text-gray-500 mb-2 line-clamp-2">{desc}</p>}
        <div className="text-xs text-gray-400 mb-2">{product.unit}</div>

        {/* Price */}
        <div className="mt-auto">
          <div className="text-xl font-extrabold text-emerald-600 mb-3">
            {priceLabel}
          </div>

          {/* Quantity selector */}
          <div className="flex items-center gap-2 mb-3">
            <button
              onClick={() => setQty(Math.max(product.min_wholesale_qty, qty - 1))}
              className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-700"
              disabled={!inStock}
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="flex-1 text-center font-bold text-gray-800">{qty}</span>
            <button
              onClick={() => setQty(qty + 1)}
              className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-gray-700"
              disabled={!inStock}
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>

          {/* Add to cart */}
          <button
            onClick={handleAdd}
            disabled={!inStock}
            className={`btn-3d w-full py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 transition-all ${
              added
                ? 'bg-emerald-500 text-white'
                : inStock
                ? 'bg-emerald-600 text-white hover:bg-emerald-700'
                : 'bg-gray-300 text-gray-500 cursor-not-allowed'
            }`}
          >
            {added ? (
              <>
                <Package className="w-4 h-4" />
                {lang === 'ar' ? 'تمت الإضافة!' : 'Added!'}
              </>
            ) : (
              <>
                <ShoppingCart className="w-4 h-4" />
                {t(lang, 'addToCart')}
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
