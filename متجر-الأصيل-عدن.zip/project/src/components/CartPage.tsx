import { ShoppingCart, Plus, Minus, Trash2, ArrowRight, ArrowLeft } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { useRoute } from '@/context/RouteContext';
import { t } from '@/lib/i18n';

export default function CartPage() {
  const { lang, currency, cart, updateQuantity, removeFromCart, cartTotalYer, cartTotalSar, cartCount } = useStore();
  const { navigate } = useRoute();

  const total = currency === 'YER' ? cartTotalYer : cartTotalSar;
  const formatted = new Intl.NumberFormat('en-US', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(total);
  const totalLabel = currency === 'YER' ? `${formatted} ر.ي` : `${formatted} ر.س`;

  const Arrow = lang === 'ar' ? ArrowLeft : ArrowRight;

  if (cart.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center">
        <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gray-100 flex items-center justify-center">
          <ShoppingCart className="w-12 h-12 text-gray-300" />
        </div>
        <h2 className="text-2xl font-bold text-gray-700 mb-4">{t(lang, 'cartEmpty')}</h2>
        <button
          onClick={() => navigate('store')}
          className="btn-3d px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700"
        >
          {t(lang, 'continueShopping')}
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-6">
        {t(lang, 'cart')} <span className="text-gray-400 text-lg">({cartCount} {t(lang, 'items')})</span>
      </h2>

      {/* Cart items */}
      <div className="space-y-3 mb-6">
        {cart.map((item) => {
          const price = currency === 'YER' ? item.product.price_yer : item.product.price_sar;
          const subTotal = price * item.quantity;
          const subFormatted = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(subTotal);
          const subLabel = currency === 'YER' ? `${subFormatted} ر.ي` : `${subFormatted} ر.س`;
          const name = lang === 'ar' ? item.product.name_ar : item.product.name_en;

          return (
            <div
              key={item.product.id}
              className="bg-white rounded-2xl p-4 shadow-md flex items-center gap-4 slide-in-right"
            >
              {/* Image */}
              <div className="w-20 h-20 rounded-xl overflow-hidden bg-gray-100 flex-shrink-0">
                {item.product.image_url ? (
                  <img src={item.product.image_url} alt={name} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-300">
                    <ShoppingCart className="w-8 h-8" />
                  </div>
                )}
              </div>

              {/* Info */}
              <div className="flex-1 min-w-0">
                <h3 className="font-bold text-gray-800 truncate">{name}</h3>
                <p className="text-sm text-gray-500">{item.product.unit}</p>
                <p className="text-sm text-emerald-600 font-semibold mt-1">{subLabel}</p>
              </div>

              {/* Quantity */}
              <div className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => updateQuantity(item.product.id, item.quantity - 1)}
                  className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
                >
                  <Minus className="w-4 h-4" />
                </button>
                <span className="w-10 text-center font-bold">{item.quantity}</span>
                <button
                  onClick={() => updateQuantity(item.product.id, item.quantity + 1)}
                  className="w-8 h-8 rounded-lg bg-gray-100 hover:bg-gray-200 flex items-center justify-center"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>

              {/* Remove */}
              <button
                onClick={() => removeFromCart(item.product.id)}
                className="w-8 h-8 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center text-red-500 flex-shrink-0"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          );
        })}
      </div>

      {/* Summary */}
      <div className="bg-white rounded-2xl p-6 shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <span className="text-lg font-bold text-gray-700">{t(lang, 'cartTotal')}</span>
          <span className="text-2xl font-extrabold text-emerald-600">{totalLabel}</span>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => navigate('store')}
            className="flex-1 py-3 rounded-xl bg-gray-100 text-gray-700 font-bold hover:bg-gray-200 transition-colors"
          >
            {t(lang, 'continueShopping')}
          </button>
          <button
            onClick={() => navigate('checkout')}
            className="flex-1 btn-3d py-3 rounded-xl bg-emerald-600 text-white font-bold hover:bg-emerald-700 flex items-center justify-center gap-2"
          >
            {t(lang, 'checkout')}
            <Arrow className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
