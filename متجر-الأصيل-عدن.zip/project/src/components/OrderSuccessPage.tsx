import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useStore } from '@/context/StoreContext';
import { useRoute } from '@/context/RouteContext';
import { t } from '@/lib/i18n';
import { CheckCircle2, Package, ArrowRight, ArrowLeft } from 'lucide-react';
import type { Order, OrderItem } from '@/types';

export default function OrderSuccessPage() {
  const { lang, currency } = useStore();
  const { params, navigate } = useRoute();
  const [order, setOrder] = useState<Order | null>(null);
  const [items, setItems] = useState<OrderItem[]>([]);

  useEffect(() => {
    (async () => {
      if (!params.orderId) return;
      const { data } = await supabase
        .from('orders')
        .select('*, order_items(*)')
        .eq('id', params.orderId)
        .maybeSingle();
      if (data) {
        setOrder(data as Order);
        setItems((data as any).order_items || []);
      }
    })();
  }, [params.orderId]);

  const Arrow = lang === 'ar' ? ArrowLeft : ArrowRight;
  const total = currency === 'YER' ? order?.total_yer : order?.total_sar;
  const formatted = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(total || 0);
  const totalLabel = currency === 'YER' ? `${formatted} ر.ي` : `${formatted} ر.س`;

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl text-center">
        <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-emerald-100 flex items-center justify-center pulse-glow">
          <CheckCircle2 className="w-12 h-12 text-emerald-600" />
        </div>

        <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-3">
          {t(lang, 'orderSuccess')}
        </h2>

        {order && (
          <>
            <div className="bg-emerald-50 rounded-xl p-4 inline-block mb-6">
              <span className="text-sm text-gray-500">{t(lang, 'orderNumber')}: </span>
              <span className="font-bold text-emerald-700">#{order.id.slice(0, 8).toUpperCase()}</span>
            </div>

            <div className="bg-gray-50 rounded-2xl p-6 text-left mb-6">
              <h3 className="font-bold text-gray-700 mb-4 flex items-center gap-2">
                <Package className="w-5 h-5 text-emerald-600" />
                {t(lang, 'orderDetails')}
              </h3>
              <div className="space-y-2 mb-4">
                {items.map((item) => {
                  const name = lang === 'ar' ? item.product_name_ar : item.product_name_en;
                  const price = currency === 'YER' ? item.subtotal_yer : item.subtotal_sar;
                  const priceF = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(price);
                  const priceL = currency === 'YER' ? `${priceF} ر.ي` : `${priceF} ر.س`;
                  return (
                    <div key={item.id} className="flex justify-between text-sm">
                      <span className="text-gray-600">{name} × {item.quantity}</span>
                      <span className="font-semibold">{priceL}</span>
                    </div>
                  );
                })}
              </div>
              <div className="border-t pt-3 flex justify-between items-center">
                <span className="font-bold text-gray-700">{t(lang, 'cartTotal')}</span>
                <span className="text-lg font-extrabold text-emerald-600">{totalLabel}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <button
                onClick={() => navigate('store')}
                className="btn-3d px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 flex items-center justify-center gap-2"
              >
                {t(lang, 'backToHome')}
                <Arrow className="w-5 h-5" />
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
