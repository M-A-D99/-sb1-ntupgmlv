import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useStore } from '@/context/StoreContext';
import { useRoute } from '@/context/RouteContext';
import { t } from '@/lib/i18n';
import { CheckCircle2, ShoppingCart, Loader2 } from 'lucide-react';

export default function CheckoutPage() {
  const { lang, currency, cart, cartTotalYer, cartTotalSar, clearCart } = useStore();
  const { navigate } = useRoute();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: '',
    phone: '',
    address: '',
    notes: '',
  });

  const total = currency === 'YER' ? cartTotalYer : cartTotalSar;
  const formatted = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(total);
  const totalLabel = currency === 'YER' ? `${formatted} ر.ي` : `${formatted} ر.س`;

  if (cart.length === 0) {
    navigate('store');
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.phone) return;

    setLoading(true);

    try {
      const { data: order, error } = await supabase
        .from('orders')
        .insert({
          customer_name: form.name,
          customer_phone: form.phone,
          customer_address: form.address,
          customer_notes: form.notes,
          currency: currency,
          total_yer: cartTotalYer,
          total_sar: cartTotalSar,
          status: 'pending',
        })
        .select()
        .single();

      if (error || !order) {
        alert(lang === 'ar' ? 'حدث خطأ، حاول مرة أخرى' : 'An error occurred, try again');
        setLoading(false);
        return;
      }

      const orderItems = cart.map((item) => ({
        order_id: order.id,
        product_id: item.product.id,
        product_name_ar: item.product.name_ar,
        product_name_en: item.product.name_en,
        unit_price_yer: item.product.price_yer,
        unit_price_sar: item.product.price_sar,
        quantity: item.quantity,
        subtotal_yer: item.product.price_yer * item.quantity,
        subtotal_sar: item.product.price_sar * item.quantity,
      }));

      const { error: itemsError } = await supabase.from('order_items').insert(orderItems);

      if (itemsError) {
        console.error('Order items error:', itemsError);
      }

      clearCart();
      navigate('order-success', { orderId: order.id });
    } catch (err) {
      console.error('Checkout error:', err);
      alert(lang === 'ar' ? 'حدث خطأ، حاول مرة أخرى' : 'An error occurred, try again');
    }

    setLoading(false);
  };

  const inputClass =
    'w-full px-4 py-3 rounded-xl border-2 border-gray-200 focus:border-emerald-500 focus:outline-none text-gray-700 bg-white';

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h2 className="text-2xl md:text-3xl font-bold text-gray-800 mb-6">{t(lang, 'checkout')}</h2>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Form */}
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 shadow-lg space-y-4">
          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">
              {t(lang, 'customerName')} *
            </label>
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              className={inputClass}
              placeholder={t(lang, 'customerName')}
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">
              {t(lang, 'customerPhone')} *
            </label>
            <input
              type="tel"
              required
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              className={inputClass}
              placeholder="7XX XXX XXX"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">
              {t(lang, 'customerAddress')}
            </label>
            <input
              type="text"
              value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })}
              className={inputClass}
              placeholder={t(lang, 'customerAddress')}
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-600 mb-1">
              {t(lang, 'customerNotes')}
            </label>
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              className={inputClass}
              rows={3}
              placeholder={t(lang, 'customerNotes')}
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="btn-3d w-full py-4 bg-emerald-600 text-white rounded-xl font-bold text-lg flex items-center justify-center gap-2 hover:bg-emerald-700 disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                {lang === 'ar' ? 'جاري...' : 'Processing...'}
              </>
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5" />
                {t(lang, 'placeOrder')}
              </>
            )}
          </button>
        </form>

        {/* Order summary */}
        <div className="bg-white rounded-2xl p-6 shadow-lg h-fit">
          <h3 className="font-bold text-lg text-gray-800 mb-4">{t(lang, 'cart')}</h3>
          <div className="space-y-3 mb-4">
            {cart.map((item) => {
              const price = currency === 'YER' ? item.product.price_yer : item.product.price_sar;
              const sub = price * item.quantity;
              const subF = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(sub);
              const subL = currency === 'YER' ? `${subF} ر.ي` : `${subF} ر.س`;
              const name = lang === 'ar' ? item.product.name_ar : item.product.name_en;
              return (
                <div key={item.product.id} className="flex justify-between text-sm">
                  <span className="text-gray-600">
                    {name} × {item.quantity}
                  </span>
                  <span className="font-semibold text-gray-700">{subL}</span>
                </div>
              );
            })}
          </div>
          <div className="border-t pt-4 flex justify-between items-center">
            <span className="font-bold text-gray-700">{t(lang, 'cartTotal')}</span>
            <span className="text-xl font-extrabold text-emerald-600">{totalLabel}</span>
          </div>
        </div>
      </div>
    </div>
  );
}
