import { useState } from 'react';
import { ShoppingCart, Globe, Coins, Store, Share2, Download, Menu, X } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { useRoute } from '@/context/RouteContext';
import { t } from '@/lib/i18n';
import type { Language, Currency } from '@/types';

export default function Header() {
  const { lang, setLang, currency, setCurrency, cartCount } = useStore();
  const { navigate, route } = useRoute();
  const [mobileMenu, setMobileMenu] = useState(false);
  const [showShare, setShowShare] = useState(false);

  const handleShare = async () => {
    const url = window.location.href;
    const shareData = {
      title: t(lang, 'storeName') + ' - ' + t(lang, 'storeCity'),
      text: t(lang, 'shareText'),
      url: url,
    };
    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch {
        setShowShare(true);
      }
    } else {
      setShowShare(true);
    }
  };

  const copyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setShowShare(false);
  };

  const handleInstall = () => {
    alert(lang === 'ar' 
      ? 'لتحميل التطبيق: افتح قائمة المتصفح واختر "إضافة إلى الشاشة الرئيسية"' 
      : 'To install: open browser menu and select "Add to Home screen"');
  };

  const navItems = [
    { label: t(lang, 'home'), route: 'store' as const },
    { label: t(lang, 'cart'), route: 'cart' as const },
    { label: t(lang, 'admin'), route: 'admin' as const },
  ];

  return (
    <>
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-md shadow-lg border-b-2 border-emerald-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <button
              onClick={() => navigate('store')}
              className="flex items-center gap-2 group"
            >
              <div className="w-10 h-10 md:w-12 md:h-12 rounded-xl bg-gradient-to-br from-emerald-600 to-teal-500 flex items-center justify-center text-white shadow-lg group-hover:scale-110 transition-transform">
                <Store className="w-6 h-6 md:w-7 md:h-7" />
              </div>
              <div className="text-right">
                <div className={`text-lg md:text-xl font-bold text-gray-800 leading-tight ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                  {t(lang, 'storeName')}
                </div>
                <div className={`text-xs text-emerald-600 leading-tight ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
                  {t(lang, 'storeCity')}
                </div>
              </div>
            </button>

            {/* Desktop nav */}
            <nav className="hidden md:flex items-center gap-6">
              {navItems.map((item) => (
                <button
                  key={item.route}
                  onClick={() => navigate(item.route)}
                  className={`font-semibold transition-colors relative px-3 py-2 rounded-lg ${
                    route === item.route
                      ? 'text-emerald-700 bg-emerald-50'
                      : 'text-gray-600 hover:text-emerald-600'
                  }`}
                >
                  {item.label}
                  {item.route === 'cart' && cartCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center badge-bounce">
                      {cartCount}
                    </span>
                  )}
                </button>
              ))}
            </nav>

            {/* Controls */}
            <div className="flex items-center gap-1 md:gap-2">
              {/* Language toggle */}
              <button
                onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}
                className="flex items-center gap-1 px-2 md:px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors text-sm font-semibold text-gray-700"
                title="Language"
              >
                <Globe className="w-4 h-4" />
                <span className="hidden sm:inline">{t(lang, 'language')}</span>
              </button>

              {/* Currency toggle */}
              <button
                onClick={() => setCurrency(currency === 'YER' ? 'SAR' : 'YER')}
                className="flex items-center gap-1 px-2 md:px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 transition-colors text-sm font-semibold text-gray-700"
                title="Currency"
              >
                <Coins className="w-4 h-4" />
                <span>{currency}</span>
              </button>

              {/* Share */}
              <button
                onClick={handleShare}
                className="flex items-center gap-1 px-2 md:px-3 py-2 rounded-lg bg-emerald-100 hover:bg-emerald-200 transition-colors text-sm font-semibold text-emerald-700"
                title={t(lang, 'shareStore')}
              >
                <Share2 className="w-4 h-4" />
              </button>

              {/* Install */}
              <button
                onClick={handleInstall}
                className="flex items-center gap-1 px-2 md:px-3 py-2 rounded-lg bg-emerald-100 hover:bg-emerald-200 transition-colors text-sm font-semibold text-emerald-700"
                title={t(lang, 'installApp')}
              >
                <Download className="w-4 h-4" />
              </button>

              {/* Cart mobile */}
              <button
                onClick={() => navigate('cart')}
                className="md:hidden relative p-2 rounded-lg text-gray-700"
              >
                <ShoppingCart className="w-5 h-5" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </button>

              {/* Mobile menu */}
              <button
                onClick={() => setMobileMenu(!mobileMenu)}
                className="md:hidden p-2 rounded-lg text-gray-700"
              >
                {mobileMenu ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile menu */}
          {mobileMenu && (
            <nav className="md:hidden pb-4 flex flex-col gap-2">
              {navItems.map((item) => (
                <button
                  key={item.route}
                  onClick={() => {
                    navigate(item.route);
                    setMobileMenu(false);
                  }}
                  className={`text-right font-semibold px-4 py-3 rounded-lg ${
                    route === item.route
                      ? 'text-emerald-700 bg-emerald-50'
                      : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  {item.label}
                  {item.route === 'cart' && cartCount > 0 && ` (${cartCount})`}
                </button>
              ))}
            </nav>
          )}
        </div>
      </header>

      {/* Share modal */}
      {showShare && (
        <div
          className="fixed inset-0 z-[60] bg-black/50 flex items-center justify-center p-4"
          onClick={() => setShowShare(false)}
        >
          <div
            className="bg-white rounded-2xl p-6 max-w-md w-full shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <h3 className="text-lg font-bold mb-4">{t(lang, 'shareStore')}</h3>
            <p className="text-gray-600 text-sm mb-4">{lang === 'ar' ? 'انسخ الرابط وشاركه:' : 'Copy the link and share:'}</p>
            <div className="flex gap-2">
              <input
                type="text"
                readOnly
                value={window.location.href}
                className="flex-1 px-3 py-2 border rounded-lg bg-gray-50 text-sm"
              />
              <button
                onClick={copyLink}
                className="px-4 py-2 bg-emerald-600 text-white rounded-lg font-semibold hover:bg-emerald-700"
              >
                {lang === 'ar' ? 'نسخ' : 'Copy'}
              </button>
            </div>
            <button
              onClick={() => setShowShare(false)}
              className="mt-4 w-full px-4 py-2 bg-gray-200 rounded-lg font-semibold hover:bg-gray-300"
            >
              {t(lang, 'cancel')}
            </button>
          </div>
        </div>
      )}
    </>
  );
}
