import { ShoppingBag, Truck, ShieldCheck, Smartphone } from 'lucide-react';
import { useStore } from '@/context/StoreContext';
import { useRoute } from '@/context/RouteContext';
import { t } from '@/lib/i18n';

export default function Hero() {
  const { lang } = useStore();
  const { navigate } = useRoute();

  return (
    <section className="relative hero-gradient overflow-hidden">
      <div className="absolute inset-0 hero-gradient-overlay" />

      {/* Floating decorative shapes */}
      <div className="absolute top-10 right-10 w-32 h-32 bg-white/10 rounded-full float-anim" />
      <div className="absolute bottom-20 left-10 w-24 h-24 bg-white/5 rounded-full float-slow" />
      <div className="absolute top-1/3 left-20 w-16 h-16 bg-yellow-300/20 rounded-3xl rotate-45 float-slow" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-28">
        <div className="text-center text-white">
          {/* 3D floating store icon */}
          <div className="inline-block mb-6 float-anim">
            <div className="w-24 h-24 md:w-32 md:h-32 bg-white/15 backdrop-blur-md rounded-3xl flex items-center justify-center shadow-2xl border border-white/30">
              <ShoppingBag className="w-12 h-12 md:w-16 md:h-16 text-white" />
            </div>
          </div>

          <h1 className="text-4xl md:text-6xl font-extrabold mb-4 drop-shadow-lg fade-in-up">
            {t(lang, 'heroTitle')}
          </h1>
          <p className="text-lg md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto fade-in-up" style={{ animationDelay: '0.1s' }}>
            {t(lang, 'heroSubtitle')}
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center fade-in-up" style={{ animationDelay: '0.2s' }}>
            <button
              onClick={() => {
                document.getElementById('products-section')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="btn-3d px-8 py-4 bg-white text-emerald-700 rounded-xl font-bold text-lg shadow-xl hover:shadow-2xl"
            >
              {t(lang, 'shopNow')}
            </button>
            <button
              onClick={() => navigate('cart')}
              className="btn-3d px-8 py-4 bg-white/20 backdrop-blur-md text-white border-2 border-white/40 rounded-xl font-bold text-lg shadow-xl hover:bg-white/30"
            >
              {t(lang, 'cart')}
            </button>
          </div>
        </div>

        {/* Features */}
        <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
          {[
            { icon: ShoppingBag, title: t(lang, 'feature1Title'), desc: t(lang, 'feature1Desc') },
            { icon: Truck, title: t(lang, 'feature2Title'), desc: t(lang, 'feature2Desc') },
            { icon: ShieldCheck, title: t(lang, 'feature3Title'), desc: t(lang, 'feature3Desc') },
            { icon: Smartphone, title: t(lang, 'feature4Title'), desc: t(lang, 'feature4Desc') },
          ].map((feature, i) => (
            <div
              key={i}
              className="glass rounded-2xl p-4 md:p-6 text-center text-white card-3d"
            >
              <feature.icon className="w-8 h-8 md:w-10 md:h-10 mx-auto mb-3 text-white" />
              <h3 className="font-bold text-sm md:text-lg mb-1">{feature.title}</h3>
              <p className="text-xs md:text-sm text-white/80">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Wave divider */}
      <div className="relative">
        <svg viewBox="0 0 1440 60" className="w-full" preserveAspectRatio="none" style={{ height: '40px' }}>
          <path d="M0,30 C360,60 720,0 1080,30 C1260,45 1380,20 1440,30 L1440,60 L0,60 Z" fill="#f8f9fa" />
        </svg>
      </div>
    </section>
  );
}
