export type Language = 'ar' | 'en';
export type Currency = 'YER' | 'SAR';

export interface Category {
  id: string;
  name_ar: string;
  name_en: string;
  slug: string;
  icon: string | null;
  sort_order: number;
}

export interface Product {
  id: string;
  category_id: string | null;
  name_ar: string;
  name_en: string;
  description_ar: string | null;
  description_en: string | null;
  price_yer: number;
  price_sar: number;
  unit: string;
  stock: number;
  min_wholesale_qty: number;
  image_url: string | null;
  is_active: boolean;
  sort_order: number;
  category?: Category;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export type OrderStatus = 'pending' | 'confirmed' | 'shipped' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string | null;
  customer_notes: string | null;
  currency: string;
  total_yer: number;
  total_sar: number;
  status: OrderStatus;
  created_at: string;
  order_items?: OrderItem[];
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string | null;
  product_name_ar: string;
  product_name_en: string;
  unit_price_yer: number;
  unit_price_sar: number;
  quantity: number;
  subtotal_yer: number;
  subtotal_sar: number;
}
