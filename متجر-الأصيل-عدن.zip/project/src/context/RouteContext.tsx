import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

export type AppRoute = 'store' | 'admin' | 'cart' | 'checkout' | 'order-success' | 'orders';

interface RouteContextValue {
  route: AppRoute;
  params: Record<string, string>;
  navigate: (route: AppRoute, params?: Record<string, string>) => void;
}

const RouteContext = createContext<RouteContextValue | null>(null);

export function RouteProvider({ children }: { children: ReactNode }) {
  const [route, setRoute] = useState<AppRoute>(() => {
    const hash = window.location.hash.replace('#', '');
    if (hash.startsWith('admin')) return 'admin';
    if (hash.startsWith('cart')) return 'cart';
    return 'store';
  });
  const [params, setParams] = useState<Record<string, string>>({});

  const navigate = (newRoute: AppRoute, newParams: Record<string, string> = {}) => {
    setRoute(newRoute);
    setParams(newParams);
    const hashParts = [newRoute, ...Object.values(newParams)].join('/');
    window.location.hash = hashParts;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    const handler = () => {
      const hash = window.location.hash.replace('#', '');
      const parts = hash.split('/');
      const baseRoute = parts[0] as AppRoute;
      if (baseRoute && ['store', 'admin', 'cart', 'checkout', 'order-success', 'orders'].includes(baseRoute)) {
        setRoute(baseRoute);
        const newParams: Record<string, string> = {};
        if (baseRoute === 'order-success' && parts[1]) {
          newParams.orderId = parts[1];
        }
        setParams(newParams);
      }
    };
    window.addEventListener('hashchange', handler);
    return () => window.removeEventListener('hashchange', handler);
  }, []);

  return (
    <RouteContext.Provider value={{ route, params, navigate }}>
      {children}
    </RouteContext.Provider>
  );
}

export function useRoute() {
  const ctx = useContext(RouteContext);
  if (!ctx) throw new Error('useRoute must be used within RouteProvider');
  return ctx;
}
