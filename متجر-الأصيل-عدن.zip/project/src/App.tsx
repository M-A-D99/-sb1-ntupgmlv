import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';
import { StoreProvider } from '@/context/StoreContext';
import { RouteProvider, useRoute } from '@/context/RouteContext';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import Categories from '@/components/Categories';
import ProductGrid from '@/components/ProductGrid';
import CartPage from '@/components/CartPage';
import CheckoutPage from '@/components/CheckoutPage';
import OrderSuccessPage from '@/components/OrderSuccessPage';
import Footer from '@/components/Footer';
import AdminLogin from '@/components/admin/AdminLogin';
import AdminDashboard from '@/components/admin/AdminDashboard';
import type { Session } from '@supabase/supabase-js';

function AppRoutes() {
  const { route } = useRoute();
  const [session, setSession] = useState<Session | null>(null);
  const [authChecked, setAuthChecked] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSession(data.session);
      setAuthChecked(true);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess);
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  // Admin route
  if (route === 'admin') {
    if (!authChecked) {
      return (
        <div className="min-h-screen flex items-center justify-center">
          <div className="w-8 h-8 border-4 border-emerald-600 border-t-transparent rounded-full animate-spin" />
        </div>
      );
    }
    if (!session) return <AdminLogin />;
    return <AdminDashboard />;
  }

  // Store routes
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-1">
        {route === 'store' && (
          <>
            <Hero />
            <Categories />
            <ProductGrid />
          </>
        )}
        {route === 'cart' && <CartPage />}
        {route === 'checkout' && <CheckoutPage />}
        {route === 'order-success' && <OrderSuccessPage />}
      </main>
      <Footer />
    </div>
  );
}

function App() {
  return (
    <StoreProvider>
      <RouteProvider>
        <AppRoutes />
      </RouteProvider>
    </StoreProvider>
  );
}

export default App;
